import CarGameController as CarGame


CarGame.game() 