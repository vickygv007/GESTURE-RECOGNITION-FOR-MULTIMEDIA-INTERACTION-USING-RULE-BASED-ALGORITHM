import tkinter as tk
import subprocess


def run_vb1():
    subprocess.Popen(["python", r"C:\Users\Vicky\Desktop\a\prject main - Copy\volbright\vb1.py"])

def run_pptcontrol():
    subprocess.Popen(["python", r"finyrppt\pptcontrol.py"])

def run_virtualsteering():
    subprocess.Popen(["python", r"C:\Users\Vicky\Desktop\a\prject main - Copy\Hand-Controller-main\pycv - Controller\virtualsteering.py"])

def run_virtualmouse():
    subprocess.Popen(["python", r"virtualmouse.py"])

def show_main_menu(): 
    for widget in root.winfo_children():
        widget.destroy()
    
    root.configure(bg="#F5F5F5")  # Soft light background

    welcome_label = tk.Label(root, text="Welcome to Hand Gesture Control", 
                             font=("Arial", 18, "bold"), fg="#333333", bg="#F5F5F5")
    welcome_label.pack(pady=30)

    start_button = tk.Button(root, text="Start", command=show_functions, font=("Arial", 16, "bold"), 
                             bg="#3F51B5", fg="white", activebackground="#303F9F", activeforeground="white",
                             padx=20, pady=10)
    start_button.pack(pady=10)

def show_functions():
    for widget in root.winfo_children():
        widget.destroy()
    
    root.configure(bg="#F5F5F5")  # Soft light background

    heading_label = tk.Label(root, text="Select a Feature", 
                             font=("Arial", 18, "bold"), fg="#333333", bg="#F5F5F5")
    heading_label.pack(pady=20)

    vb1_button = tk.Button(root, text="Volume & Brightness Control", command=run_vb1, 
                           font=("Arial", 14), bg="#E91E63", fg="white", activebackground="#C2185B", 
                           width=30, height=2)
    vb1_button.pack(pady=10)
    
    ppt_button = tk.Button(root, text="PowerPoint Control", command=run_pptcontrol, 
                           font=("Arial", 14), bg="#00BCD4", fg="white", activebackground="#0097A7", 
                           width=30, height=2)
    ppt_button.pack(pady=10)
    
    steering_button = tk.Button(root, text="Virtual Steering", command=run_virtualsteering, 
                                font=("Arial", 14), bg="#4CAF50", fg="white", activebackground="#388E3C", 
                                width=30, height=2)
    steering_button.pack(pady=10)
    
    mouse_button = tk.Button(root, text="Virtual Mouse", command=run_virtualmouse, 
                             font=("Arial", 14), bg="#FF9800", fg="white", activebackground="#F57C00", 
                             width=30, height=2)
    mouse_button.pack(pady=10)
    
    back_button = tk.Button(root, text="Back", command=show_main_menu, 
                            font=("Arial", 14), bg="#9E9E9E", fg="white", activebackground="#757575", 
                            width=30, height=2)
    back_button.pack(pady=20)


root = tk.Tk()
root.title("Hand Gesture Controller")
root.geometry("500x500")  # Slightly increased size for spacing

show_main_menu()
root.mainloop()
