import cv2
import numpy as np
import mediapipe as mp
import screen_brightness_control as sbc
from math import hypot
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL


# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    static_image_mode=False,
    model_complexity=1,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7,
    max_num_hands=2)

draw = mp.solutions.drawing_utils

# Initialize Pycaw for Volume Control
devices = AudioUtilities.GetSpeakers()
interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
volume = cast(interface, POINTER(IAudioEndpointVolume))
vol_range = volume.GetVolumeRange()
min_vol, max_vol, _ = vol_range

# Start Webcam Capture
cap = cv2.VideoCapture(0)

def get_distance(lm1, lm2):
    """Calculate the Euclidean distance between two landmarks."""
    x1, y1 = lm1
    x2, y2 = lm2
    return hypot(x2 - x1, y2 - y1)

def adjust_volume_and_brightness(hand_landmarks, width, height, is_left_hand):
    """Adjusts volume if it's a left hand and brightness if it's a right hand."""
    if hand_landmarks:
        thumb = hand_landmarks[4]  # Thumb tip (tuple: (x, y))
        index = hand_landmarks[8]  # Index finger tip (tuple: (x, y))
        
        # Convert to screen coordinates
        thumb_pos = (int(thumb[0] * width), int(thumb[1] * height))
        index_pos = (int(index[0] * width), int(index[1] * height))
        
        # Draw circles and line between thumb & index
        cv2.circle(frame, thumb_pos, 7, (0, 255, 0), cv2.FILLED)
        cv2.circle(frame, index_pos, 7, (0, 255, 0), cv2.FILLED)
        cv2.line(frame, thumb_pos, index_pos, (0, 255, 0), 3)
        
        # Measure distance
        distance = get_distance(thumb_pos, index_pos)
        
        # Adjust volume or brightness
        if is_left_hand:
            vol_level = np.interp(distance, [30, 200], [min_vol, max_vol])
            volume.SetMasterVolumeLevel(vol_level, None)
        else:
            brightness_level = np.interp(distance, [30, 200], [0, 100])
            sbc.set_brightness(int(brightness_level))



while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)  # Mirror the frame
    height, width, _ = frame.shape

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    processed = hands.process(frame_rgb)

    if processed.multi_hand_landmarks:
        for hand_no, hand_landmarks in enumerate(processed.multi_hand_landmarks):
            # Draw landmarks on frame
            draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            
            # Check if it's the left or right hand
            hand_label = "Right" if hand_no == 0 else "Left"  # Mirrored, so reversed
            
            # Convert landmarks to a list of tuples (x, y)
            landmark_list = [(lm.x, lm.y) for lm in hand_landmarks.landmark]
            
            # Adjust volume for left hand, brightness for right hand
            adjust_volume_and_brightness(landmark_list, width, height, is_left_hand=(hand_label == "Left"))

    # Display the frame
    cv2.imshow('Hand Gesture Volume & Brightness Control', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release resources
cap.release()
cv2.destroyAllWindows()
