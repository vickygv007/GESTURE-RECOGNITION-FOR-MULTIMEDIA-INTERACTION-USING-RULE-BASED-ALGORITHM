import cv2
import mediapipe as mp
import pyautogui

# Initialize Mediapipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.7)
mp_draw = mp.solutions.drawing_utils

# Start capturing video
cap = cv2.VideoCapture(0)

# Get screen size
screen_width, screen_height = pyautogui.size()

# Ensure camera is open
if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()

def fingers_status(landmarks):
    """Checks which fingers are up"""
    fingers = []
    tips = [4, 8, 12, 16, 20]  # Thumb, Index, Middle, Ring, Pinky
    for i in range(5):
        if i == 0:  # Thumb special case (checks x direction)
            fingers.append(landmarks[tips[i]].x < landmarks[tips[i] - 2].x)
        else:  # Other fingers (check y direction)
            fingers.append(landmarks[tips[i]].y < landmarks[tips[i] - 2].y)
    return fingers  # [Thumb, Index, Middle, Ring, Pinky]

while True:
    success, frame = cap.read()
    if not success:
        print("Error: Failed to capture image.")
        break

    frame = cv2.flip(frame, 1)  # Flip for natural movement
    height, width, _ = frame.shape
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Process the frame
    results = hands.process(frame_rgb)

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

            # Get the status of fingers
            finger_states = fingers_status(hand_landmarks.landmark)

            # Cursor Movement: Index, Middle, and Thumb open; Ring & Pinky closed
            if finger_states[1] and finger_states[2] and finger_states[0] and not finger_states[3] and not finger_states[4]:
                index_finger = hand_landmarks.landmark[8]
                x, y = int(index_finger.x * width), int(index_finger.y * height)
                screen_x = int(index_finger.x * screen_width)
                screen_y = int(index_finger.y * screen_height)
                pyautogui.moveTo(screen_x, screen_y, duration=0.1)

            # Left Click: Thumb closed, Index + Middle open
            if not finger_states[0] and finger_states[1] and finger_states[2]:
                pyautogui.click()
                pyautogui.sleep(0.2)  # Prevent multiple clicks

            # Right Click: Index + Middle closed, Ring + Pinky closed
            if not finger_states[1] and not finger_states[2] and not finger_states[3] and not finger_states[4]:
                pyautogui.rightClick()
                pyautogui.sleep(0.2)

    # Show the camera feed
    cv2.imshow("Gesture Mouse Control", frame)

    # Exit on pressing 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
